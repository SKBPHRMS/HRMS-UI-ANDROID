package com.example.hrsystem;

import android.app.Application;

public class GlobalClass extends Application {
    private String emp_id;

    public String getEmpid()
    {
        return emp_id;
    }
    public void setEmpid(String emp_id){
        this.emp_id=emp_id;
    }
}
