package com.example.hrsystem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class AdminDashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);
    }
}