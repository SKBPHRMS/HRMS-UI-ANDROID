package com.example.logingactivity.postdata;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.service.autofill.TextValueSanitizer;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.logingactivity.R;

import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;

import javax.net.ssl.HttpsURLConnection;



public class PostData extends AppCompatActivity implements
        View.OnClickListener {
    private ProgressDialog progress;


    TextView tvName;
    TextView tvCountry;
    TextView tvCity;
    TextView tvaddress;
    TextView tvzipcode;
    TextView tvphone;
    TextView tvemail;
    TextView tvmstatus;
    TextView tvage;

    Button btnDatePicker;
    EditText txtDate;
    String date;
    Button button;
    String name;
    String country;
    String  address;
    String  city;
    String zipcode;
    String   phone;
    String mstatus;


    RadioButton radioButton1;
    RadioGroup radioGroup33;

    String  email;
    String getgender;
    String study;
    String course;
    DatePicker picker;

    EditText ssc;
    EditText yearscl;
    EditText resultscl;
    EditText sclname;

    EditText clgcourse;
    EditText yearclg;
    EditText resultclg;
    EditText clgname;

    EditText degcourse;
    EditText yeardeg;
    EditText resultdeg;
    EditText degname;

    EditText mstcourse;
    EditText yearmst;
    EditText resultmst;
    EditText mstname;

    EditText title1;
    EditText yearemp;
    EditText compname1;

    EditText title2;
    EditText yearemp2;
    EditText compname2;

    String Stitle1;
    String Syearemp;
    String Scompname1;

    String Stitle2;
    String Syearemp2;
    String Scompname2;
    public int mYear, mMonth, mDay;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {

            actionBar.setBackgroundDrawable(getResources().getDrawable(R.drawable.gradient_toolbar));
        }



        final RadioGroup rbg=(RadioGroup) findViewById(R.id.radioGroup1);
        final RadioGroup radioGroup3 = findViewById(R.id.radioGroup3);
        button=(Button)findViewById(R.id.btn_submit);
        tvName=(EditText)findViewById(R.id.input_name);
        tvCountry=(EditText)findViewById(R.id.input_country);
        tvaddress = (EditText)findViewById(R.id.input_address);
        tvCity =(EditText)findViewById(R.id.input_city);
        tvzipcode=(EditText)findViewById(R.id.input_zipcode);
        tvphone=(EditText)findViewById(R.id.input_phone);
        tvemail=(EditText)findViewById(R.id.input_email);
        btnDatePicker=(Button)findViewById(R.id.btn_date);
        radioGroup33 = (RadioGroup) findViewById(R.id.radioGroup3);


        tvage =(TextView) findViewById(R.id.input_age);
        txtDate=(EditText)findViewById(R.id.in_date);
        btnDatePicker.setOnClickListener(this);
        tvmstatus=(EditText)findViewById(R.id.input_mstatus);

        //education
        ssc=(EditText)findViewById(R.id.input_course_scl);
        yearscl=(EditText)findViewById(R.id.input_scl_year);
        resultscl=(EditText)findViewById(R.id.input_result_scl);
        sclname=(EditText)findViewById(R.id.input_sclname);

        clgcourse=(EditText)findViewById(R.id.input_course_clg);
        yearclg=(EditText)findViewById(R.id.input_year_clg);
        resultclg=(EditText)findViewById(R.id.input_result_clg);
        clgname=(EditText)findViewById(R.id.input_clgname);

        degcourse=(EditText)findViewById(R.id.input_course_deg);
        yeardeg=(EditText)findViewById(R.id.input_year_deg);
        resultdeg=(EditText)findViewById(R.id.input_result_deg);
        degname=(EditText)findViewById(R.id.input_degname);

        mstcourse=(EditText)findViewById(R.id.input_course_mst);
        yearmst=(EditText)findViewById(R.id.input_year_mst);
        resultmst=(EditText)findViewById(R.id.input_result_mst);
        mstname=(EditText)findViewById(R.id.input_mstname);


        title1=(EditText)findViewById(R.id.input_title1);
        yearemp=(EditText)findViewById(R.id.input_emp_year);
        compname1=(EditText)findViewById(R.id.input_comp_name);

        title2=(EditText)findViewById(R.id.input_title2);
        yearemp2=(EditText)findViewById(R.id.input_year_emp);
        compname2=(EditText)findViewById(R.id.input_comp_name2);

        final RadioGroup radioGroup = findViewById(R.id.radioGroup1);
        if (radioGroup != null) {
            radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {

                    getgender = (R.id.radioMale == checkedId) ? "male" : "female";

                }
            });
        }

        final RadioGroup radioGroup2 = findViewById(R.id.radioGroup2);
        if (radioGroup2 != null) {
            radioGroup2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {

                    study = (R.id.radioSYes == checkedId) ? "Yes" : "No";

                }
            });
        }





        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if( tvName.getText().toString().isEmpty()){

                    tvName.setError( " Name is required!" );

                }else {
                    name = tvName.getText().toString();

                }

                if( tvCountry.getText().toString().isEmpty()){


                    tvCountry.setError( " Country is required!" );

                }else{
                    country = tvCountry.getText().toString();
                }

                if( tvaddress.getText().toString().isEmpty()){



                    tvaddress.setError( "Address  is required!" );

                }else{

                    address = tvaddress.getText().toString();

                }

                if( tvCity.getText().toString().isEmpty()){



                    tvCity.setError( "City is required!" );

                }else{

                    city = tvCity.getText().toString();
                }
                if( tvemail.getText().toString().isEmpty()){



                    tvemail.setError( "Email is required!" );

                }else {
                    email = tvemail.getText().toString();
                }
                if( tvzipcode.getText().toString().isEmpty()){



                    tvzipcode.setError( "Pincode is required!" );

                }else {
                    zipcode = tvzipcode.getText().toString();
                }

                if( tvphone.getText().toString().isEmpty()){



                    tvphone.setError( "Phone NO. is required!" );

                }else{
                    phone ="+91"+ tvphone.getText().toString();

                }
                if( tvmstatus.getText().toString().isEmpty()){



                    tvmstatus.setError( "Marital Status is required!" );

                }else{
                    mstatus = tvmstatus.getText().toString();
                }


                int selectedId =radioGroup33.getCheckedRadioButtonId();
                radioButton1 = (RadioButton) findViewById(selectedId);





                Stitle1=  title1.getText().toString();

                Syearemp    = yearemp.getText().toString();
                Scompname1  = compname1.getText().toString();

                Stitle2    = title2.getText().toString();
                Syearemp2     = yearemp2.getText().toString();
                Scompname2  =  compname2.getText().toString();


                new SendRequest().execute();










                // find the radiobutton by returned id



            }

        }   );



    }



    public class SendRequest extends AsyncTask<String, Void, String> {



        protected void onPreExecute(){}

        protected String doInBackground(String... arg0) {

            try{

                URL url = new URL("https://script.google.com/macros/s/AKfycbwUS-lobfZa9GUm-Ox82CImKLbeEvcCmgBqmSqDwJUrJyqrFKlN/exec");

                JSONObject postDataParams = new JSONObject();

                //int i;
                //for(i=1;i<=70;i++)


                //    String usn = Integer.toString(i);

                String id= "1mKLY5asB_H33ZTPuXBHDXfKdnqCRmJArH-45IY4sMg4";

                postDataParams.put("name",name);
                postDataParams.put("address",address);
                postDataParams.put("city",city);
                postDataParams.put("zipcode",zipcode);
                postDataParams.put("country",country);
                postDataParams.put("phone",phone);
                postDataParams.put("email",email);
                postDataParams.put("gender",getgender);
                postDataParams.put("dob",txtDate.getText().toString());
                postDataParams.put("mstatus",mstatus);
                postDataParams.put("study",study);
                postDataParams.put("course",radioButton1.getText().toString());
                postDataParams.put("age",tvage.getText().toString());
                postDataParams.put("id",id);

                postDataParams.put("ssc",ssc.getText().toString());
                postDataParams.put("sclyear",yearscl.getText().toString());
                postDataParams.put("sclresult",resultscl.getText().toString());
                postDataParams.put("sclname",sclname.getText().toString());

                postDataParams.put("clgcourse",clgcourse.getText().toString());
                postDataParams.put("clgyear",yearclg.getText().toString());
                postDataParams.put("clgresult",resultclg.getText().toString());
                postDataParams.put("clgname",clgname.getText().toString());

                postDataParams.put("degcourse",degcourse.getText().toString());
                postDataParams.put("degyear",yeardeg.getText().toString());
                postDataParams.put("degresult",resultdeg.getText().toString());
                postDataParams.put("degname",degname.getText().toString());

                postDataParams.put("mstcourse",mstcourse.getText().toString());
                postDataParams.put("mstyear",yearmst.getText().toString());
                postDataParams.put("mstresult",resultmst.getText().toString());
                postDataParams.put("mstname",mstname.getText().toString());

                postDataParams.put("etitle1",Stitle1);
                postDataParams.put("eYear1",Syearemp);
                postDataParams.put("eComp1",Scompname1);
                postDataParams.put("etitle2",Stitle2);
                postDataParams.put("eYear2",Syearemp2);
                postDataParams.put("eComp2",Scompname2);

                Log.e("Title:",Syearemp);

                Log.e("params",postDataParams.toString());



                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000 /* milliseconds */);
                conn.setConnectTimeout(15000 /* milliseconds */);
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode=conn.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {

                    BufferedReader in=new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuffer sb = new StringBuffer("");
                    String line="";

                    while((line = in.readLine()) != null) {

                        sb.append(line);
                        break;
                    }

                    in.close();
                    return sb.toString();

                }
                else {
                    return new String("false : "+responseCode);
                }
            }
            catch(Exception e){
                return new String("Exception: " + e.getMessage());
            }
        }

        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(getApplicationContext(), result,
                    Toast.LENGTH_LONG).show();

        }
    }

    public String getPostDataString(JSONObject params) throws Exception {

        StringBuilder result = new StringBuilder();
        boolean first = true;

        Iterator<String> itr = params.keys();

        while(itr.hasNext()){

            String key= itr.next();
            Object value = params.get(key);

            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(key, "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(value.toString(), "UTF-8"));

        }
        return result.toString();

    }


    public void onClick(View v) {

        if (v == btnDatePicker) {

            // Get Current Date
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);



            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {


                            txtDate.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);
                            getAge( year, monthOfYear, dayOfMonth);

                        }

                    }, mYear, mMonth, mDay);

            datePickerDialog.show();


        }

    }
    private String getAge(int year, int month, int day){
        Calendar dob = Calendar.getInstance();
        Calendar today = Calendar.getInstance();

        dob.set(year, month, day);

        int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);

        if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)){
            age--;
        }

        Integer ageInt = new Integer(age);
        String ageS = ageInt.toString();
        tvage.setText("Age: "+ageS);
        return ageS;

    }




}


